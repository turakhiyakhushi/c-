package unit_2;
abstract class shape{
    abstract void draw();
}
class rectangle extends shape{
    void draw(){
        System.out.println("drawing rectangle");
    }
}
class circle extends shape{
    void draw(){
        System.out.println("drawing circle");
    }
}
class TestAbstrction{
    public static void main(String args[])
    {
        shape s1=new circle();
        shape s2=new rectangle();
        s1.draw();
        s2.draw();
    }
}