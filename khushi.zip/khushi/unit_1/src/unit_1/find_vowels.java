
package unit_1;


public class find_vowels {
    public static void main(String[]args)
    {
        char ch='L';
        switch(ch)
        {
            case'a':
                System.out.println("vowel");
                break;
             
             case'e':
                System.out.println("vowel");
                break;
                
             case'i':
                System.out.println("vowel");
                break;
                
            case'o':
                System.out.println("vowel");
                break;
               
            case'u':
                System.out.println("vowel");
                break;
              
             case'K':
                System.out.println("vowel");
                break;
            
            case'H':
                System.out.println("vowel");
                break;
                
            case'U':
                System.out.println("vowel");
                break;
                
              case'S':
                System.out.println("vowel");
                break;
                
            case'I':
                System.out.println("vowel");
                break;
                
            default:
                System.out.println("consonant");
        }
    } 
    
}
