
package unit_1;

public class java_variables {
    public static void main(String[]args)
    {
        int i=10;
        String n="Java";
        float f=5.5f;
        System.out.println("value of i:"+i);
        System.out.println("value of n:"+n);
        System.out.println("value of f:"+f);
    }
    
}
